-- AddColumn
ALTER TABLE "users" ADD COLUMN "profilePicture" TEXT;